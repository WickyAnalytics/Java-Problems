/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elml3b;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class Receipt {
 private int Receipt_ID;
 
   
    //relation
    
    Receipt Rec=new Receipt();
    ArrayList<Receipt> REc =new ArrayList() ;
    Employee p ;
    Payment paymmm;
    
    public void add(Receipt REc)
    {
        this.REc.add(REc);
    }

    public Receipt(int Receipt_ID, Employee p, Payment paymmm) {
        this.Receipt_ID = Receipt_ID;
        this.p = p;
        this.paymmm = paymmm;
    }
   
    Receipt() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
   Scanner in = new Scanner(System.in);
   
   
    public Receipt(int Receipt_ID) {
        this.Receipt_ID = Receipt_ID;
        
    }
  
  

    public int getReceipt_ID() {
        return Receipt_ID;
    }

    public void setReceipt_ID(int Receipt_ID) {
               Random rand = new Random(); 
       
      int upperbound = 1000;
       
     Receipt_ID   = rand.nextInt(upperbound); 
    }
     
  public boolean receiptSubmit(int Receipt_ID, int Reservation_ID, int Payment_ID){
        
        int z = in.nextInt();
        int x = in.nextInt();
        if(z == Reservation_ID && x == Payment_ID){
            return true;
        }else
            return false;
    }
}