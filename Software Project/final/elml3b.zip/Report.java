/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elml3b;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class Report {
    Scanner in=new Scanner(System.in);
     ArrayList<Complaint> cm;
    private int Report_ID;
    private int Report_Code;
    private String Report_Type;
    
    //relation
    Complaint oo;
    Report rr=new Report();
    Manger mm;

    public Report(int Report_ID,int Report_Code,String Report_Type, Complaint oo, Manger mm){
    this.Report_ID=Report_ID;
    this.Report_Code=Report_Code;
    this.Report_Type=Report_Type;   
           this.oo = oo;
           this.mm = mm ;

}    

    
    public Report(int Report_ID) {
          Random rand = new Random(); 
       
      int upperbound = 1000;
       
     Report_ID = rand.nextInt(upperbound); 
    }

    Report() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public int getReport_ID() {
        return Report_ID;
    }

    public void setReport_ID(int Report_ID) {
        this.Report_ID = Report_ID;
    }
    public boolean reportSubmit(){
        return false;
    }

public boolean ReportSubmit(boolean Complaint_Submit){
if (Complaint_Submit==true){
return true;
}
return false;
}
public boolean Report_Type(String Report_Type){
    System.out.println("Choose the type of Report Type");
    String s=in.nextLine();
    if (s=="Complaint")
        return true;
    else 
        return false;
}

}
