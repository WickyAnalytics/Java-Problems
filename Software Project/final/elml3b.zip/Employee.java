/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elml3b;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
/**
 *
 * @author Lenovo
 */
public class Employee extends Staff {

      
      //relation
       Employee p =new Employee();
       ArrayList<Employee> pp =new ArrayList() ;

       Manger mm;

       public void add(Employee pp)
       {
           this.pp.add(pp);
       }
    public ArrayList<Reservation> getRes() {
        return Res;
    }

    public ArrayList<Receipt> getREc() {
        return REc;
    }
       
        ArrayList <Payment> Paymm ;
        
       ArrayList <Reservation> Res ;
       
       ArrayList<Receipt> REc;

    public Employee(ArrayList<Reservation> Res, ArrayList<Receipt> REc) {
        this.Res = Res;
        this.REc = REc;
    }


     

    public Employee(Manger mm, int Staff_ID, int Staff_phone, String Staff_username, String Staff_name, String Staff_userPassword) {
        super(Staff_ID, Staff_phone, Staff_username, Staff_name, Staff_userPassword);
        this.mm = mm;
    }

    /**
     *
     * @param getReservation_ID
     */
    public void PrintReceipt ( ArrayList <Reservation>  Reservation_ID ,ArrayList<Receipt> Receipt_ID ){

    System.out.print("Reservation  "+ Reservation_ID);
    System.out.print(",");
    System.out.print("Receipt  "+ Receipt_ID);
    
}

    Employee() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
 
 public boolean ConfirmPayment ( int GEtPayments_ID,int MakeReservation ,boolean ConfirmReservation,boolean Payments_method, int Payment_ID){
     

if(GEtPayments_ID==Payment_ID&&Payments_method==true&&ConfirmReservation==true)
     
          return true;
else 
    return false;
}    
  public boolean ConfirmReservation ( int Reservation_ID){
      if (Reservation_ID!=0)
  return true;
      else
          return false;
  } 
  public boolean login(){
 
      if(Staff_userPassword=="01234567890"){
    
         return true;
     
     }
      
     return false;
       

}
 public void Logout(){
  
 }

}
