/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elml3b;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Lenovo
 */
public class Complaint {
    private int Complaint_ID;
   private String Complaint_Details;
  // relation 
  Complaint oo=new Complaint();
   Customer AA;
    Report rr;

    public Customer getAA() {
        return AA;
    }
  
   
   Complaint() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getComplaint_Details() {
        return Complaint_Details;
    }

    public void setComplaint_Details(String Complaint_Details) {
        this.Complaint_Details = Complaint_Details;
    }

    public Complaint(int Complaint_ID, String Complaint_Details) {
        this.Complaint_ID = Complaint_ID;
        this.Complaint_Details = Complaint_Details;
    
    }

   
    
    
    public int getComplaint_ID() {
        return Complaint_ID;
    }

    public void setComplaint_ID(int Complaint_ID) {
              Random rand = new Random(); 
       
      int upperbound = 1000;
       
     Complaint_ID   = rand.nextInt(upperbound); 
    }
    
    
    public boolean Complaint_Submit( String MakeComplaint){
    if (Complaint_Details != null) {
     
          
    
        return true;
    }
    return false ;
    }


    
}
   
