
package elml3b;

import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class Field {
    private int Field_ID;
    private String Field_Name;
    private Boolean Field_Status;

 //relation
    
Field f=new Field();

Manger mm;

Reservation res;
   


    public String getField_Name() {
        return Field_Name;
    }

    public void setField_Name(String Field_Name) {
        this.Field_Name = Field_Name;
    }

    
    Field() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

    public int getField_ID() {
        return Field_ID;
    }

    public void setField_ID(int Field_ID) {
        
       ArrayList<Integer>Field=new ArrayList<>();
     
      Field.add(0);
      Field.add(1);
      Field.add(2);
      Field.add(3);
      Field.add(4);
    }
public Field (int Field_ID,String Field_Name,boolean Field_Status, Manger mm , Reservation res){
this.Field_ID=Field_ID;
this.Field_Name=Field_Name;
this.Field_Status=Field_Status;
this.mm = mm;
  this.res = res;
}

  
public boolean FieldState(boolean Field_Status){
    
    int i=0;
        
    while(i<10){
        i++;
        return true;
    
    
    }
   
    return false;
}
}
