/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elml3b;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class Manger extends Staff {
     Scanner in=new Scanner(System.in);
     //relation
     Manger mm=new Manger();
     Report rr;
     ArrayList<Field> f;
     ArrayList<Employee> pp;
     
     public void add(Employee pp)
       {
           this.pp.add(pp);
       }
     public void add(Field f)
       {
           this.f.add(f);
       }


    public Manger(int Staff_ID, int Staff_phone, String Staff_username, String Staff_name, String Staff_userPassword) {
        super(Staff_ID, Staff_phone, Staff_username, Staff_name, Staff_userPassword);

    }

    Manger() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void addempolyee (int Staff_ID, int Staff_phone, String Staff_username, String Staff_name, String Staff_userPassword){
        System.out.println ("Please Enter Data ");

        System.out.println ("Please Enter Employee ID");
         Staff_ID = in.nextInt();
    System.out.println ("Please Enter Employee Phone ");
             Staff_phone = in.nextInt();

    System.out.println ("Please Enter Employee  User Name");
             Staff_username = in.nextLine();

    System.out.println ("Please Enter Employee Name ");
             Staff_name = in.nextLine();

    System.out.println ("Please Enter Employee Password ");
             Staff_userPassword = in.nextLine();
    }
 
  public void removeEmployee (int Staff_ID){
        
        System.out.println("Please enter employee id you wish to remove");
        Staff_ID = in.nextInt();
        System.out.println("Employee that has id "+ Staff_ID +" is removed successfully");
    }
   public void generateReport(int Report_ID, String Report_Details){
        System.out.println("Please enter Report ID");
        Report_ID = in.nextInt();
        System.out.println("Please enter report details");
        Report_Details = in.next();
        System.out.println("Report That has ID: "+ Report_ID +"has been generated successfully contains: "+ Report_Details);
    }
public void disabeldfield(  ArrayList<Integer>Field ){
System.out.println("Enter field number you wish to disabeld betwen less than 10");
int s=in.nextInt();

if (s<10)

Field.remove(s);

else 
    System.out.println("please enter correct number ") ;
}

public void enableldfield(  ArrayList<Integer>Field ){
    


System.out.println("Enter field number you wish to enable <10 ");

int s=in.nextInt();

if (s<10)

Field.add(s);

else 
    System.out.println("please enter correct number ") ;
}
 public boolean login(){
   if(Staff_userPassword=="520551"){
    
         return true;
     
     }
     return false;
       

}
 public void Logout(){
  
 }
}



