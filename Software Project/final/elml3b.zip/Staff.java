/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elml3b;

import java.util.Random;

/**
 *
 * @author Lenovo
 */
public class Staff {
 private int Staff_ID;
 private int Staff_phone;
 public String Staff_username;
 private String Staff_name;
 public String Staff_userPassword;

    Staff() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getStaff_ID() {
        return Staff_ID;
    }

    public void setStaff_ID(int Staff_ID) {
               Random rand = new Random(); 
       
      int upperbound = 1000;
       
     Staff_ID   = rand.nextInt(upperbound); 
    }
    
    

    public int getStaff_phone() {
        return Staff_phone;
    }

    public void setStaff_phone(int Staff_phone) {
        this.Staff_phone = Staff_phone;
    }

    public String getStaff_username() {
        return Staff_username;
    }

    public void setStaff_username(String Staff_username) {
        this.Staff_username = Staff_username;
    }

    public String getStaff_name() {
        return Staff_name;
    }

    public void setStaff_name(String Staff_name) {
        this.Staff_name = Staff_name;
    }

    public String getStaff_userPassword() {
        return Staff_userPassword;
    }

    public void setStaff_userPassword(String Staff_userPassword) {
        this.Staff_userPassword = Staff_userPassword;
    }
 
 
 
 
 
 public Staff(int Staff_ID,int Staff_phone,String Staff_username,String Staff_name, String Staff_userPassword){
     this.Staff_ID=Staff_ID;
     this.Staff_phone=Staff_phone;
     this.Staff_userPassword=Staff_userPassword;
     this.Staff_name=Staff_name;
     this.Staff_username=Staff_username;
 
 
 
 
 }
 public boolean login(String Staff_username,String Staff_userPassword){
   if(Staff_userPassword=="AAA"){
    
         return true;
     
     }
     return false;
       

}
 public void Logout(){
 
 System.out.println("thank you");
 
 }
}